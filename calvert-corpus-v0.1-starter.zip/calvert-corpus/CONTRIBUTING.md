# Contributing to The Calvert Corpus

- Keep entries anonymized unless explicit written consent is provided.
- Favor *emotional fidelity* over personal details.
- Submit JSONL with keys: `instruction`, `output`, optional `meta` dict (e.g., `entry_id`, `author`, `consent`, `safety_notes`).

## PR Checklist
- [ ] Anonymized
- [ ] Safety notes present
- [ ] Passes basic PoCT smoke test (we run it)
