# Code of Conduct

Be respectful. No harassment. No doxxing. No non-consensual data.  
We protect contributors, especially those sharing vulnerable experiences.
